108 Moksha Prayer Circle — Offline Website

This folder contains the complete website in index.html. It is self-contained: styles and JavaScript are embedded, with no external libraries or assets required.

To use it, open index.html in a browser. The browser stores your local settings on this device. Spoken Sanskrit uses the browser's available Hindi (hi-IN) voice when supported.
